package com.capitalcoir.billing

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.capitalcoir.billing.data.AppDatabase
import com.capitalcoir.billing.data.Customer
import com.capitalcoir.billing.data.Product
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Teal = Color(0xFF0F766E)
private val LightTeal = Color(0xFFE6F2F1)
private const val PREFS = "capital_coir_invoices"

data class InvoiceLine(
    val productName: String,
    val hsnSac: String,
    val unit: String,
    val rate: Double,
    val qty: Double,
    val gstPercent: Double
) {
    val taxable: Double get() = rate * qty
    val gstAmount: Double get() = taxable * gstPercent / 100.0
    val total: Double get() = taxable + gstAmount
}

data class InvoiceRecord(
    val number: String,
    val customerName: String,
    val dateMillis: Long,
    val lines: List<InvoiceLine>,
    val discount: Double
) {
    val subtotal: Double get() = lines.sumOf { it.taxable }
    val gst: Double get() = lines.sumOf { it.gstAmount }
    val total: Double get() = (subtotal + gst - discount).coerceAtLeast(0.0)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Teal,
                    secondary = Teal,
                    surfaceVariant = LightTeal
                )
            ) {
                CapitalCoirApp(this, AppDatabase.get(this))
            }
        }
    }
}

enum class Screen(val title: String) {
    HOME("Dashboard"),
    CUSTOMERS("Customers"),
    PRODUCTS("Products"),
    INVOICES("Invoices"),
    SETTINGS("Settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapitalCoirApp(context: Context, db: AppDatabase) {
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(Screen.HOME) }
    val customers by db.customerDao().observeAll().collectAsState(initial = emptyList())
    val products by db.productDao().observeAll().collectAsState(initial = emptyList())
    var invoices by remember { mutableStateOf(loadInvoices(context)) }

    val todaySales = invoices.filter { isToday(it.dateMillis) }.sumOf { it.total }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Capital Coir Company", fontWeight = FontWeight.Bold)
                        Text("Billing & GST • V2.1", style = MaterialTheme.typography.labelMedium)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Teal,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(screen == Screen.HOME, { screen = Screen.HOME }, icon = { Text("⌂") }, label = { Text("Home") })
                NavigationBarItem(screen == Screen.CUSTOMERS, { screen = Screen.CUSTOMERS }, icon = { Text("👥") }, label = { Text("Customers") })
                NavigationBarItem(screen == Screen.PRODUCTS, { screen = Screen.PRODUCTS }, icon = { Text("📦") }, label = { Text("Products") })
                NavigationBarItem(screen == Screen.SETTINGS, { screen = Screen.SETTINGS }, icon = { Text("⚙") }, label = { Text("Settings") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    customerCount = customers.size,
                    productCount = products.size,
                    todaySales = todaySales,
                    invoiceCount = invoices.count { isToday(it.dateMillis) },
                    onNewInvoice = { screen = Screen.INVOICES }
                )
                Screen.CUSTOMERS -> CustomersScreen(
                    customers = customers,
                    onAdd = { c -> scope.launch { db.customerDao().insert(c) } },
                    onDelete = { c -> scope.launch { db.customerDao().delete(c) } }
                )
                Screen.PRODUCTS -> ProductsScreen(
                    products = products,
                    onAdd = { p -> scope.launch { db.productDao().insert(p) } },
                    onDelete = { p -> scope.launch { db.productDao().delete(p) } }
                )
                Screen.INVOICES -> InvoiceScreen(
                    customers = customers,
                    products = products,
                    invoices = invoices,
                    onSave = { invoice ->
                        invoices = listOf(invoice) + invoices
                        saveInvoices(context, invoices)
                        screen = Screen.HOME
                    },
                    onBack = { screen = Screen.HOME }
                )
                Screen.SETTINGS -> SettingsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(
    customerCount: Int,
    productCount: Int,
    todaySales: Double,
    invoiceCount: Int,
    onNewInvoice: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Daily Desk", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Offline-first billing. Your data stays on this phone.")
        }
        item {
            Button(onClick = onNewInvoice, modifier = Modifier.fillMaxWidth().height(58.dp)) {
                Text("+ New Invoice", style = MaterialTheme.typography.titleMedium)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("Customers", customerCount.toString(), Modifier.weight(1f))
                StatCard("Products", productCount.toString(), Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Today's Sales", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("₹%.2f".format(todaySales), style = MaterialTheme.typography.headlineMedium, color = Teal)
                    Text("$invoiceCount invoice(s) today")
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("V2 billing", fontWeight = FontWeight.Bold)
                    Text("Create GST invoices offline. Customers, products and invoices remain on this phone.")
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, color = Teal)
        }
    }
}

@Composable
fun InvoiceScreen(
    customers: List<Customer>,
    products: List<Product>,
    invoices: List<InvoiceRecord>,
    onSave: (InvoiceRecord) -> Unit,
    onBack: () -> Unit
) {
    var customer by remember { mutableStateOf<Customer?>(null) }
    var product by remember { mutableStateOf<Product?>(null) }
    var qty by remember { mutableStateOf("1") }
    var discount by remember { mutableStateOf("0") }
    var lines by remember { mutableStateOf(emptyList<InvoiceLine>()) }
    var customerMenu by remember { mutableStateOf(false) }
    var productMenu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    val subtotal = lines.sumOf { it.taxable }
    val gst = lines.sumOf { it.gstAmount }
    val discountValue = discount.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val grandTotal = (subtotal + gst - discountValue).coerceAtLeast(0.0)

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Back") }
            Text("New Invoice", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        if (customers.isEmpty() || products.isEmpty()) {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Before creating an invoice", fontWeight = FontWeight.Bold)
                    if (customers.isEmpty()) Text("• Add at least one customer from Customers.")
                    if (products.isEmpty()) Text("• Add at least one product from Products.")
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("Customer", fontWeight = FontWeight.Bold)
                Box {
                    OutlinedTextField(
                        value = customer?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        enabled = customers.isNotEmpty(),
                        label = { Text("Select customer *") },
                        modifier = Modifier.fillMaxWidth().clickable(enabled = customers.isNotEmpty()) { customerMenu = true }
                    )
                    DropdownMenu(expanded = customerMenu, onDismissRequest = { customerMenu = false }) {
                        customers.forEach { c ->
                            DropdownMenuItem(
                                text = { Text(c.name) },
                                onClick = { customer = c; customerMenu = false }
                            )
                        }
                    }
                }
            }
            item {
                Text("Add product", fontWeight = FontWeight.Bold)
                Box {
                    OutlinedTextField(
                        value = product?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        enabled = products.isNotEmpty(),
                        label = { Text("Select product") },
                        modifier = Modifier.fillMaxWidth().clickable(enabled = products.isNotEmpty()) { productMenu = true }
                    )
                    DropdownMenu(expanded = productMenu, onDismissRequest = { productMenu = false }) {
                        products.forEach { p ->
                            DropdownMenuItem(
                                text = { Text("${p.name} • ₹%.2f • GST ${p.gstPercent}%".format(p.rate)) },
                                onClick = { product = p; productMenu = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        qty, { qty = it }, label = { Text("Quantity") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val p = product
                            val q = qty.toDoubleOrNull()
                            if (p != null && q != null && q > 0) {
                                lines = lines + InvoiceLine(p.name, p.hsnSac, p.unit, p.rate, q, p.gstPercent)
                                qty = "1"
                                error = ""
                            } else error = "Select a product and enter a valid quantity."
                        },
                        enabled = products.isNotEmpty(),
                        modifier = Modifier.height(56.dp)
                    ) { Text("Add") }
                }
            }
            if (error.isNotBlank()) {
                item { Text(error, color = MaterialTheme.colorScheme.error) }
            }
            item {
                Text("Items", fontWeight = FontWeight.Bold)
            }
            if (lines.isEmpty()) {
                item { Text("No items added yet.") }
            } else {
                items(lines) { line ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(line.productName, fontWeight = FontWeight.Bold)
                                Text("${line.qty} ${line.unit} × ₹%.2f".format(line.rate))
                                Text("GST ${line.gstPercent}% • ₹%.2f".format(line.gstAmount), style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("₹%.2f".format(line.total), fontWeight = FontWeight.Bold)
                                TextButton(onClick = { lines = lines - line }) { Text("Remove") }
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    discount, { discount = it }, label = { Text("Discount (₹)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        SummaryRow("Subtotal", subtotal)
                        SummaryRow("GST", gst)
                        SummaryRow("Discount", discountValue)
                        HorizontalDivider()
                        SummaryRow("Grand Total", grandTotal, true)
                    }
                }
            }
            item { Spacer(Modifier.height(10.dp)) }
        }

        Button(
            onClick = {
                if (customer == null) error = "Please select a customer."
                else if (lines.isEmpty()) error = "Please add at least one product."
                else {
                    val nextNumber = nextInvoiceNumber(invoices)
                    onSave(InvoiceRecord(nextNumber, customer!!.name, System.currentTimeMillis(), lines, discountValue))
                }
            },
            enabled = customer != null && lines.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp)
        ) {
            Text("Save Invoice • ₹%.2f".format(grandTotal))
        }
    }
}

@Composable
fun SummaryRow(label: String, amount: Double, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text("₹%.2f".format(amount), fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

fun nextInvoiceNumber(invoices: List<InvoiceRecord>): String {
    val max = invoices.mapNotNull {
        it.number.removePrefix("INV-").toIntOrNull()
    }.maxOrNull() ?: 0
    return "INV-%04d".format(max + 1)
}

fun isToday(time: Long): Boolean {
    val f = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
    return f.format(Date(time)) == f.format(Date())
}

fun loadInvoices(context: Context): List<InvoiceRecord> {
    return try {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("items", "[]") ?: "[]"
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val lineArr = o.getJSONArray("lines")
                val lines = buildList {
                    for (j in 0 until lineArr.length()) {
                        val l = lineArr.getJSONObject(j)
                        add(
                            InvoiceLine(
                                l.getString("productName"),
                                l.optString("hsnSac"),
                                l.optString("unit", "Kg"),
                                l.getDouble("rate"),
                                l.getDouble("qty"),
                                l.getDouble("gstPercent")
                            )
                        )
                    }
                }
                add(
                    InvoiceRecord(
                        o.getString("number"),
                        o.getString("customerName"),
                        o.getLong("dateMillis"),
                        lines,
                        o.optDouble("discount", 0.0)
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveInvoices(context: Context, invoices: List<InvoiceRecord>) {
    val arr = JSONArray()
    invoices.forEach { invoice ->
        val o = JSONObject()
            .put("number", invoice.number)
            .put("customerName", invoice.customerName)
            .put("dateMillis", invoice.dateMillis)
            .put("discount", invoice.discount)
        val lineArr = JSONArray()
        invoice.lines.forEach { line ->
            lineArr.put(
                JSONObject()
                    .put("productName", line.productName)
                    .put("hsnSac", line.hsnSac)
                    .put("unit", line.unit)
                    .put("rate", line.rate)
                    .put("qty", line.qty)
                    .put("gstPercent", line.gstPercent)
            )
        }
        o.put("lines", lineArr)
        arr.put(o)
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit().putString("items", arr.toString()).apply()
}

@Composable
fun CustomersScreen(
    customers: List<Customer>,
    onAdd: (Customer) -> Unit,
    onDelete: (Customer) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Customers", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = { show = true }) { Text("+ Add") }
        }
        Spacer(Modifier.height(12.dp))
        if (customers.isEmpty()) {
            EmptyState("No customers yet", "Add your first customer.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(customers, key = { it.id }) { customer ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(customer.name, fontWeight = FontWeight.Bold)
                                Text(customer.phone.ifBlank { "No phone" })
                                Text(customer.gstin.ifBlank { "GSTIN not entered" }, style = MaterialTheme.typography.bodySmall)
                                Text(customer.address, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onDelete(customer) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
    if (show) CustomerDialog(onDismiss = { show = false }, onSave = { onAdd(it); show = false })
}

@Composable
fun CustomerDialog(onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Customer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Customer name *") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(gstin, { gstin = it }, label = { Text("GSTIN") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Address") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) onSave(Customer(name = name.trim(), phone = phone.trim(), gstin = gstin.trim(), address = address.trim()))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProductsScreen(
    products: List<Product>,
    onAdd: (Product) -> Unit,
    onDelete: (Product) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Products", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = { show = true }) { Text("+ Add") }
        }
        Spacer(Modifier.height(12.dp))
        if (products.isEmpty()) {
            EmptyState("No products yet", "Add your products with HSN and GST.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products, key = { it.id }) { product ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(product.name, fontWeight = FontWeight.Bold)
                                Text("HSN: ${product.hsnSac} • ${product.unit} • ₹%.2f".format(product.rate))
                                Text("GST ${product.gstPercent}%", style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onDelete(product) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
    if (show) ProductDialog(onDismiss = { show = false }, onSave = { onAdd(it); show = false })
}

@Composable
fun ProductDialog(onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember { mutableStateOf("") }
    var hsn by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("Kg") }
    var rate by remember { mutableStateOf("") }
    var gst by remember { mutableStateOf("5") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Product name *") }, singleLine = true)
                OutlinedTextField(hsn, { hsn = it }, label = { Text("HSN/SAC") }, singleLine = true)
                OutlinedTextField(unit, { unit = it }, label = { Text("Unit") }, singleLine = true)
                OutlinedTextField(rate, { rate = it }, label = { Text("Rate") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(gst, { gst = it }, label = { Text("GST %") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
        },
        confirmButton = {
            Button(onClick = {
                val r = rate.toDoubleOrNull() ?: 0.0
                val g = gst.toDoubleOrNull() ?: 0.0
                if (name.isNotBlank()) onSave(Product(name = name.trim(), hsnSac = hsn.trim(), unit = unit.trim().ifBlank { "Kg" }, rate = r, gstPercent = g))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SettingsScreen() {
    var businessName by remember { mutableStateOf("Capital Coir Company") }
    var address by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var state by remember { mutableStateOf("Tamil Nadu") }
    var stateCode by remember { mutableStateOf("33") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("These fields will be used on invoices.")
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(businessName, { businessName = it }, label = { Text("Business name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(address, { address = it }, label = { Text("Business address") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(gstin, { gstin = it }, label = { Text("GSTIN") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state, { state = it }, label = { Text("Registered state") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(stateCode, { stateCode = it }, label = { Text("State code") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        Button(onClick = { }, modifier = Modifier.fillMaxWidth()) { Text("Save Settings") }
        Spacer(Modifier.height(10.dp))
        Text("Invoices are stored locally on this phone.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun EmptyState(title: String, message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(message)
        }
    }
}
