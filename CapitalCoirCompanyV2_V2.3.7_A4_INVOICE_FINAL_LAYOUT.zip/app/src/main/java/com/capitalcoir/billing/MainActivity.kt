package com.capitalcoir.billing

import android.content.Context
import android.os.Bundle
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import com.capitalcoir.billing.data.AppDatabase
import com.capitalcoir.billing.data.Customer
import com.capitalcoir.billing.data.Product
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Teal = Color(0xFF0F766E)
private val LightTeal = Color(0xFFE6F2F1)
private const val PREFS = "capital_coir_invoices"

data class InvoiceLine(
    val productName: String,
    val hsnSac: String,
    val unit: String,
    val rate: Double,
    val qty: Double,
    val gstPercent: Double,
    val bundles: Double = 0.0,
    val weightKg: Double = 0.0
) {
    val taxable: Double get() = rate * qty
    val gstAmount: Double get() = taxable * gstPercent / 100.0
    val total: Double get() = taxable + gstAmount
}

data class InvoiceRecord(
    val number: String,
    val customerName: String,
    val dateMillis: Long,
    val lines: List<InvoiceLine>,
    val discount: Double,
    val shippedFrom: String = "",
    val shippedTo: String = "",
    val vehicleName: String = "",
    val vehicleNumber: String = "",
    val driverName: String = "",
    val driverDl: String = ""
) {
    val subtotal: Double get() = lines.sumOf { it.taxable }
    val gst: Double get() = lines.sumOf { it.gstAmount }
    val total: Double get() = (subtotal + gst - discount).coerceAtLeast(0.0)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Teal,
                    secondary = Teal,
                    surfaceVariant = LightTeal
                )
            ) {
                CapitalCoirApp(this, AppDatabase.get(this))
            }
        }
    }
}

enum class Screen(val title: String) {
    HOME("Dashboard"),
    CUSTOMERS("Customers"),
    PRODUCTS("Products"),
    INVOICES("Invoices"),
    SETTINGS("Settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapitalCoirApp(context: Context, db: AppDatabase) {
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(Screen.HOME) }
    val customers by db.customerDao().observeAll().collectAsState(initial = emptyList())
    val products by db.productDao().observeAll().collectAsState(initial = emptyList())
    var invoices by remember { mutableStateOf(loadInvoices(context)) }
    var savedInvoice by remember { mutableStateOf<InvoiceRecord?>(null) }
    var showNewInvoice by remember { mutableStateOf(false) }

    val todaySales = invoices.filter { isToday(it.dateMillis) }.sumOf { it.total }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Capital Coir Company", fontWeight = FontWeight.Bold)
                        Text("Billing & GST • V2.3.6", style = MaterialTheme.typography.labelMedium)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Teal,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(screen == Screen.HOME, { screen = Screen.HOME }, icon = { Text("⌂") }, label = { Text("Home") })
                NavigationBarItem(screen == Screen.CUSTOMERS, { screen = Screen.CUSTOMERS }, icon = { Text("👥") }, label = { Text("Customers") })
                NavigationBarItem(screen == Screen.PRODUCTS, { screen = Screen.PRODUCTS }, icon = { Text("📦") }, label = { Text("Products") })
                NavigationBarItem(screen == Screen.INVOICES, { screen = Screen.INVOICES; showNewInvoice = false }, icon = { Text("🧾") }, label = { Text("Invoices") })
                NavigationBarItem(screen == Screen.SETTINGS, { screen = Screen.SETTINGS }, icon = { Text("⚙") }, label = { Text("Settings") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    customerCount = customers.size,
                    productCount = products.size,
                    todaySales = todaySales,
                    invoiceCount = invoices.count { isToday(it.dateMillis) },
                    onNewInvoice = { screen = Screen.INVOICES; showNewInvoice = true }
                )
                Screen.CUSTOMERS -> CustomersScreen(
                    customers = customers,
                    onAdd = { c -> scope.launch { db.customerDao().insert(c) } },
                    onDelete = { c -> scope.launch { db.customerDao().delete(c) } }
                )
                Screen.PRODUCTS -> ProductsScreen(
                    products = products,
                    onAdd = { p -> scope.launch { db.productDao().insert(p) } },
                    onDelete = { p -> scope.launch { db.productDao().delete(p) } }
                )
                Screen.INVOICES -> if (showNewInvoice) {
                    InvoiceScreen(
                        customers = customers,
                        products = products,
                        invoices = invoices,
                        onSave = { invoice ->
                            invoices = listOf(invoice) + invoices
                            saveInvoices(context, invoices)
                            savedInvoice = invoice
                            showNewInvoice = false
                        },
                        onBack = { showNewInvoice = false }
                    )
                } else {
                    InvoiceHistoryScreen(
                        invoices = invoices,
                        customers = customers,
                        onNewInvoice = { showNewInvoice = true },
                        onBack = { screen = Screen.HOME }
                    )
                }
                Screen.SETTINGS -> SettingsScreen(context)
            }
        }
    }

    savedInvoice?.let { invoice ->
        val customer = customers.firstOrNull { it.name == invoice.customerName }
        AlertDialog(
            onDismissRequest = { savedInvoice = null; screen = Screen.INVOICES; showNewInvoice = false },
            title = { Text("Invoice Saved") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${invoice.number} has been saved successfully.")
                    Text("You can now create a professional A4 PDF or send it to a printer.")
                }
            },
            confirmButton = {
                Button(onClick = {
                    createAndPrintInvoicePdf(context, invoice, customer)
                    savedInvoice = null
                    screen = Screen.INVOICES
                    showNewInvoice = false
                }) { Text("Print / PDF") }
            },
            dismissButton = {
                TextButton(onClick = {
                    createAndShareInvoicePdf(context, invoice, customer)
                    savedInvoice = null
                    screen = Screen.INVOICES
                    showNewInvoice = false
                }) { Text("Share PDF") }
            }
        )
    }
}

@Composable
fun HomeScreen(
    customerCount: Int,
    productCount: Int,
    todaySales: Double,
    invoiceCount: Int,
    onNewInvoice: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Daily Desk", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Offline-first billing. Your data stays on this phone.")
        }
        item {
            Button(onClick = onNewInvoice, modifier = Modifier.fillMaxWidth().height(58.dp)) {
                Text("+ New Invoice", style = MaterialTheme.typography.titleMedium)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("Customers", customerCount.toString(), Modifier.weight(1f))
                StatCard("Products", productCount.toString(), Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Today's Sales", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("₹%.2f".format(todaySales), style = MaterialTheme.typography.headlineMedium, color = Teal)
                    Text("$invoiceCount invoice(s) today")
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("V2 billing", fontWeight = FontWeight.Bold)
                    Text("Create GST invoices offline. Customers, products and invoices remain on this phone.")
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, color = Teal)
        }
    }
}

@Composable
fun InvoiceHistoryScreen(
    invoices: List<InvoiceRecord>,
    customers: List<Customer>,
    onNewInvoice: () -> Unit,
    onBack: () -> Unit
) {
    var selectedInvoice by remember { mutableStateOf<InvoiceRecord?>(null) }
    val context = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onBack) { Text("← Back") }
            Text("Previous Invoices", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        Button(
            onClick = onNewInvoice,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(52.dp)
        ) { Text("+ New Invoice") }

        if (invoices.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("No saved invoices yet.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(invoices, key = { "${it.number}_${it.dateMillis}" }) { invoice ->
                    val customer = customers.firstOrNull { it.name == invoice.customerName }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Invoice ${invoice.number}", fontWeight = FontWeight.Bold, color = Teal)
                                Text("₹%.2f".format(Locale.US, kotlin.math.round(invoice.total)), fontWeight = FontWeight.Bold)
                            }
                            Text("Date: ${SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date(invoice.dateMillis))}")
                            Text("Customer: ${customer?.name ?: invoice.customerName}")
                            Text("${invoice.lines.size} item(s) • ${invoice.lines.sumOf { it.bundles }.let(::formatNumber)} bundles", style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { selectedInvoice = invoice },
                                    modifier = Modifier.weight(1f)
                                ) { Text("View") }
                                OutlinedButton(
                                    onClick = { createAndPrintInvoicePdf(context, invoice, customer) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Print / PDF") }
                                Button(
                                    onClick = { createAndShareInvoicePdf(context, invoice, customer) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Share") }
                            }
                        }
                    }
                }
            }
        }
    }

    selectedInvoice?.let { invoice ->
        val customer = customers.firstOrNull { it.name == invoice.customerName }
        AlertDialog(
            onDismissRequest = { selectedInvoice = null },
            title = { Text("Invoice ${invoice.number}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Date: ${SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date(invoice.dateMillis))}")
                    Text("Customer: ${customer?.name ?: invoice.customerName}", fontWeight = FontWeight.Bold)
                    customer?.gstin?.takeIf { it.isNotBlank() }?.let { Text("GSTIN: $it") }
                    Text("Items: ${invoice.lines.size}")
                    invoice.lines.forEach { line ->
                        Text("• ${line.productName} — ${formatNumber(line.bundles)} bundles / ${formatNumber(line.weightKg)} Kg — ₹%.2f".format(Locale.US, line.total))
                    }
                    HorizontalDivider()
                    Text("Subtotal: ₹%.2f".format(Locale.US, invoice.subtotal))
                    Text("GST: ₹%.2f".format(Locale.US, invoice.gst))
                    if (invoice.discount > 0) Text("Discount: ₹%.2f".format(Locale.US, invoice.discount))
                    val roundedTotal = kotlin.math.round(invoice.total)
                    Text("Grand Total: ₹%.2f".format(Locale.US, roundedTotal), fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(onClick = {
                    createAndPrintInvoicePdf(context, invoice, customer)
                    selectedInvoice = null
                }) { Text("Print / PDF") }
            },
            dismissButton = {
                TextButton(onClick = {
                    createAndShareInvoicePdf(context, invoice, customer)
                    selectedInvoice = null
                }) { Text("Share PDF") }
            }
        )
    }
}

@Composable
fun InvoiceScreen(
    customers: List<Customer>,
    products: List<Product>,
    invoices: List<InvoiceRecord>,
    onSave: (InvoiceRecord) -> Unit,
    onBack: () -> Unit
) {
    var customer by remember { mutableStateOf<Customer?>(null) }
    var product by remember { mutableStateOf<Product?>(null) }
    var bundles by remember { mutableStateOf("1") }
    var weightKg by remember { mutableStateOf("") }
    var discount by remember { mutableStateOf("0") }
    var invoiceNumber by remember { mutableStateOf("") }
    var shippedFrom by remember { mutableStateOf("Capital Coir Company, 26-D Makkan Street, Omalur") }
    var shippedTo by remember { mutableStateOf("") }
    var vehicleName by remember { mutableStateOf("") }
    var vehicleNumber by remember { mutableStateOf("") }
    var driverName by remember { mutableStateOf("") }
    var driverDl by remember { mutableStateOf("") }
    var lines by remember { mutableStateOf<List<InvoiceLine>>(emptyList()) }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var showProductPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    val subtotal = lines.sumOf { it.taxable }
    val gst = lines.sumOf { it.gstAmount }
    val discountValue = discount.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val grandTotal = (subtotal + gst - discountValue).coerceAtLeast(0.0)

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Back") }
            Text("New Invoice", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        if (customers.isEmpty() || products.isEmpty()) {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Before creating an invoice", fontWeight = FontWeight.Bold)
                    if (customers.isEmpty()) Text("• Add at least one customer from Customers.")
                    if (products.isEmpty()) Text("• Add at least one product from Products.")
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text("Invoice Number", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = invoiceNumber,
                    onValueChange = { invoiceNumber = it },
                    label = { Text("Invoice No. *") },
                    placeholder = { Text("029/2026-2027") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Text("Customer", fontWeight = FontWeight.Bold)
                PickerField(
                    label = "Select customer *",
                    value = customer?.name ?: "",
                    enabled = customers.isNotEmpty(),
                    onClick = { showCustomerPicker = true }
                )
            }
            item {
                Text("Shipment Details", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(shippedFrom, { shippedFrom = it }, label = { Text("Shipped From") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(shippedTo, { shippedTo = it }, label = { Text("Shipped To") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(vehicleName, { vehicleName = it }, label = { Text("Vehicle Name") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(vehicleNumber, { vehicleNumber = it }, label = { Text("Vehicle Number") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(driverName, { driverName = it }, label = { Text("Driver Name") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(driverDl, { driverDl = it }, label = { Text("DL Number") }, modifier = Modifier.weight(1f), singleLine = true)
                }
            }
            item {
                Text("Add product", fontWeight = FontWeight.Bold)
                PickerField(
                    label = "Select product",
                    value = product?.name ?: "",
                    enabled = products.isNotEmpty(),
                    onClick = { showProductPicker = true }
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = bundles,
                        onValueChange = {
                            bundles = it
                            val b = it.toDoubleOrNull()
                            val bw = product?.bundleWeightKg ?: 0.0
                            if (b != null && b >= 0 && bw > 0) {
                                weightKg = formatNumber(b * bw)
                            }
                        },
                        label = { Text("Bundles") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = weightKg,
                        onValueChange = { weightKg = it },
                        label = { Text("Weight (Kg)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    when {
                        (product?.bundleWeightKg ?: 0.0) > 0 -> {
                            val bw = product?.bundleWeightKg ?: 0.0
                            "1 bundle = ${formatNumber(bw)} Kg. Weight is auto-calculated from bundles; you can edit the actual weight."
                        }
                        product?.unit?.lowercase()?.contains("kg") == true ->
                            "Rate is applied per Kg. Enter the actual weight."
                        else ->
                            "Enter the number of bundles and, if needed, the actual weight in Kg."
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = {
                        // Build the invoice line defensively so malformed numeric input
                        // can never bring down the activity.
                        try {
                            val selected = product
                            val b = bundles.trim().replace(",", "").toDoubleOrNull() ?: 0.0
                            val w = weightKg.trim().replace(",", "").toDoubleOrNull() ?: 0.0

                            if (selected == null) {
                                error = "Select a product."
                            } else if (!b.isFinite() || !w.isFinite() || b < 0.0 || w < 0.0) {
                                error = "Enter valid bundle and weight values."
                            } else {
                                val isKgProduct = selected.unit.trim().lowercase(Locale.ROOT).contains("kg")
                                val billingQty = if (isKgProduct) w else b
                                if (!billingQty.isFinite() || billingQty <= 0.0) {
                                    error = if (isKgProduct) "Enter a valid weight in Kg." else "Enter a valid bundle quantity."
                                } else if (!selected.rate.isFinite() || !selected.gstPercent.isFinite()) {
                                    error = "This product has an invalid rate/GST. Please edit the product."
                                } else {
                                    val newLine = InvoiceLine(
                                        productName = selected.name,
                                        hsnSac = selected.hsnSac,
                                        unit = selected.unit,
                                        rate = selected.rate,
                                        qty = billingQty,
                                        gstPercent = selected.gstPercent,
                                        bundles = b,
                                        weightKg = w
                                    )
                                    // Replace the immutable list instead of mutating a snapshot list.
                                    // This gives Compose a new observable value and avoids crashes during
                                    // the recomposition triggered by adding an invoice line.
                                    lines = lines + newLine
                                    bundles = "1"
                                    weightKg = ""
                                    error = ""
                                }
                            }
                        } catch (_: Exception) {
                            error = "Unable to add this product. Please check the values and try again."
                        }
                    },
                    enabled = products.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text("Add Product") }
            }
            if (error.isNotBlank()) {
                item { Text(error, color = MaterialTheme.colorScheme.error) }
            }
            item {
                Text("Items", fontWeight = FontWeight.Bold)
            }
            if (lines.isEmpty()) {
                item { Text("No items added yet.") }
            } else {
                itemsIndexed(
                    items = lines,
                    key = { index, line -> "${line.productName}_${line.rate}_${line.qty}_${line.bundles}_${line.weightKg}_$index" }
                ) { index, line ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(line.productName, fontWeight = FontWeight.Bold)
                                val measurement = buildList {
                                    if (line.bundles > 0) add("${line.bundles} bundle${if (line.bundles == 1.0) "" else "s"}")
                                    if (line.weightKg > 0) add("${line.weightKg} Kg")
                                }.joinToString(" • ")
                                Text(if (measurement.isNotBlank()) "$measurement × ₹%.2f".format(line.rate) else "${line.qty} ${line.unit} × ₹%.2f".format(line.rate))
                                Text("GST ${line.gstPercent}%% • ₹%.2f".format(line.gstAmount), style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("₹%.2f".format(line.total), fontWeight = FontWeight.Bold)
                                TextButton(onClick = { lines = lines.filterIndexed { i, _ -> i != index } }) { Text("Remove") }
                            }
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    discount, { discount = it }, label = { Text("Discount (₹)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        SummaryRow("Subtotal", subtotal)
                        SummaryRow("GST", gst)
                        SummaryRow("Discount", discountValue)
                        HorizontalDivider()
                        SummaryRow("Grand Total", grandTotal, true)
                    }
                }
            }
            item { Spacer(Modifier.height(10.dp)) }
        }

        Button(
            onClick = {
                if (invoiceNumber.trim().isBlank()) error = "Please enter the invoice number."
                else if (customer == null) error = "Please select a customer."
                else if (lines.isEmpty()) error = "Please add at least one product."
                else {
                    onSave(InvoiceRecord(
                        number = invoiceNumber.trim(),
                        customerName = customer!!.name,
                        dateMillis = System.currentTimeMillis(),
                        lines = lines,
                        discount = discountValue,
                        shippedFrom = shippedFrom.trim(),
                        shippedTo = shippedTo.trim(),
                        vehicleName = vehicleName.trim(),
                        vehicleNumber = vehicleNumber.trim(),
                        driverName = driverName.trim(),
                        driverDl = driverDl.trim()
                    ))
                }
            },
            enabled = invoiceNumber.trim().isNotBlank() && customer != null && lines.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp)
        ) {
            Text("Save Invoice • ₹%.2f".format(grandTotal))
        }
    }

    if (showCustomerPicker) {
        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("Select Customer") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(customers, key = { it.id }) { c ->
                        OutlinedButton(
                            onClick = { customer = c; showCustomerPicker = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(c.name, fontWeight = FontWeight.Bold)
                                if (c.phone.isNotBlank()) Text(c.phone, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showCustomerPicker = false }) { Text("Cancel") } }
        )
    }

    if (showProductPicker) {
        Dialog(
            onDismissRequest = { showProductPicker = false },
            properties = androidx.compose.ui.window.DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = true,
                usePlatformDefaultWidth = false
            )
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .heightIn(min = 220.dp, max = 620.dp),
                shape = RoundedCornerShape(20.dp),
                tonalElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Select Product",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { showProductPicker = false }) {
                            Text("Cancel")
                        }
                    }
                    HorizontalDivider()
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(products, key = { it.id }) { p ->
                            Card(Modifier.fillMaxWidth()) {
                                TextButton(
                                    onClick = {
                                        product = p
                                        val b = bundles.toDoubleOrNull() ?: 0.0
                                        weightKg = if (p.bundleWeightKg > 0.0 && b > 0.0) {
                                            formatNumber(b * p.bundleWeightKg)
                                        } else {
                                            ""
                                        }
                                        showProductPicker = false
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    contentPadding = PaddingValues(14.dp)
                                ) {
                                    Column(Modifier.fillMaxWidth()) {
                                        Text(p.name, fontWeight = FontWeight.Bold)
                                        Text(
                                            "₹%.2f / %s • GST %.0f%%".format(p.rate, p.unit, p.gstPercent),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        if (p.bundleWeightKg > 0.0) {
                                            Text(
                                                "1 bundle = ${formatNumber(p.bundleWeightKg)} Kg",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun PickerField(
    label: String,
    value: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = Teal)
        Spacer(Modifier.height(4.dp))
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = value.ifBlank { "Tap to select" },
                    style = MaterialTheme.typography.bodyLarge
                )
                Text("▼")
            }
        }
    }
}

@Composable
fun SummaryRow(label: String, amount: Double, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text("₹%.2f".format(amount), fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}


private fun invoicePdfFile(context: Context, invoice: InvoiceRecord, customer: Customer?): File {
    val file = File(context.cacheDir, "${invoice.number.replace('/', '-')}.pdf")
    val document = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 at 72 dpi
    val page = document.startPage(pageInfo)
    val canvas = page.canvas
    val invoiceGrey = android.graphics.Color.rgb(215, 215, 215)
    val dark = android.graphics.Color.rgb(35, 35, 35)
    val grey = android.graphics.Color.rgb(90, 90, 90)
    val light = android.graphics.Color.rgb(235, 235, 235)
    val white = android.graphics.Color.WHITE
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
    val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif", Typeface.BOLD) }

    fun txt(value: String, x: Float, yy: Float, size: Float, p: Paint = paint, color: Int = dark) {
        p.textSize = size; p.color = color
        canvas.drawText(value, x, yy, p)
    }
    fun wrap(value: String, maxChars: Int): List<String> {
        if (value.isBlank()) return emptyList()
        val words = value.replace("\n", " ").split(Regex("\\s+")).filter { it.isNotBlank() }
        val out = mutableListOf<String>(); var line = ""
        for (w in words) {
            if (line.isBlank()) line = w
            else if ((line.length + 1 + w.length) <= maxChars) line += " $w"
            else { out += line; line = w }
        }
        if (line.isNotBlank()) out += line
        return out
    }
    fun money(v: Double) = "₹%.2f".format(Locale.US, v)
    fun hline(yy: Float) { paint.color = light; paint.strokeWidth = 1f; canvas.drawLine(30f, yy, 565f, yy, paint) }
    fun box(l: Float, t: Float, r: Float, b: Float, color: Int) { paint.color = color; canvas.drawRect(l, t, r, b, paint) }

    val prefs = context.getSharedPreferences("capital_coir_settings", Context.MODE_PRIVATE)
    val address = prefs.getString("address", "26-D Makkan Street, Omalur (Tk), Salem (Dt) - 636455, Tamilnadu. Mob: 8130070178")
        ?.takeIf { it.isNotBlank() }
        ?: "26-D Makkan Street, Omalur (Tk), Salem (Dt) - 636455, Tamilnadu. Mob: 8130070178"
    val gstin = prefs.getString("gstin", "") ?: ""
    val state = prefs.getString("state", "Tamil Nadu") ?: "Tamil Nadu"
    val stateCode = prefs.getString("stateCode", "33") ?: "33"

    // Header
    box(0f, 0f, 595f, 108f, invoiceGrey)
    txt("Capital Coir Company", 30f, 35f, 28f, bold, dark)
    txt("Dealers in Coco Coir Yarn & Ropes", 30f, 55f, 11f, bold, dark)
    val addrLines = wrap(address, 72)
    addrLines.take(2).forEachIndexed { i, line -> txt(line, 30f, 70f + i * 13f, 9f, paint, dark) }
    if (gstin.isNotBlank()) txt("GSTIN: $gstin", 30f, 96f, 9f, paint, dark)
    txt("TAX INVOICE", 400f, 31f, 18f, bold, dark)
    txt("Invoice No: ${invoice.number}", 390f, 53f, 9f, paint, dark)
    txt("Date: ${SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date(invoice.dateMillis))}", 390f, 69f, 9f, paint, dark)
    txt("Place of Supply: $state ($stateCode)", 390f, 85f, 8f, paint, dark)

    // Customer block
    var y = 124f
    txt("CUSTOMER DETAILS", 30f, y, 10f, bold, grey)
    y += 17f
    box(30f, y - 12f, 565f, y + 64f, android.graphics.Color.rgb(248, 248, 248))
    txt(customer?.name ?: invoice.customerName, 40f, y + 8f, 11f, bold)
    customer?.gstin?.takeIf { it.isNotBlank() }?.let { txt("GSTIN: $it", 40f, y + 24f, 8.5f) }
    customer?.phone?.takeIf { it.isNotBlank() }?.let { txt("Mobile: $it", 300f, y + 24f, 8.5f) }
    val custAddr = customer?.address.orEmpty()
    wrap(custAddr, 70).take(2).forEachIndexed { i, line -> txt(line, 40f, y + 41f + i * 11f, 8.5f) }
    y += 86f

    // Compact shipment details
    txt("SHIPMENT DETAILS", 30f, y, 10f, bold, grey)
    y += 8f
    box(30f, y, 565f, y + 60f, white)
    paint.style = Paint.Style.STROKE; paint.color = light; canvas.drawRect(30f, y, 565f, y + 60f, paint); paint.style = Paint.Style.FILL
    val mid = 300f
    txt("Shipped From: ${invoice.shippedFrom.ifBlank { "-" }}", 40f, y + 14f, 8f)
    txt("Shipped To: ${invoice.shippedTo.ifBlank { "-" }}", mid + 10f, y + 14f, 8f)
    txt("Vehicle Name: ${invoice.vehicleName.ifBlank { "-" }}", 40f, y + 31f, 8f)
    txt("Vehicle Number: ${invoice.vehicleNumber.ifBlank { "-" }}", mid + 10f, y + 31f, 8f)
    txt("Driver Name: ${invoice.driverName.ifBlank { "-" }}", 40f, y + 48f, 8f)
    txt("DL Number: ${invoice.driverDl.ifBlank { "-" }}", mid + 10f, y + 48f, 8f)
    y += 74f

    // Items table
    val tableTop = y
    box(30f, tableTop, 565f, tableTop + 25f, invoiceGrey)
    val cols = listOf("#" to 38f, "Product Description" to 54f, "HSN" to 214f, "Bundles" to 255f, "Rate" to 306f, "Kg" to 363f, "GST" to 414f, "Amount" to 485f)
    cols.forEach { (h, x) -> txt(h, x, tableTop + 16f, 7.5f, bold, dark) }
    y = tableTop + 43f
    invoice.lines.forEachIndexed { i, l ->
        if (y > 618f) return@forEachIndexed
        txt("${i + 1}", 38f, y, 7.5f)
        txt(l.productName.take(27), 54f, y, 7.5f, bold)
        txt(l.hsnSac.take(10).ifBlank { "-" }, 214f, y, 7.5f)
        txt(formatNumber(l.bundles).take(8), 255f, y, 7.5f)
        txt(money(l.rate), 306f, y, 7.2f)
        txt(formatNumber(l.weightKg).take(9), 363f, y, 7.5f)
        txt("%.0f%%".format(Locale.US, l.gstPercent), 414f, y, 7.5f)
        txt(money(l.taxable), 485f, y, 7.5f)
        y += 22f; hline(y - 9f)
    }

    // Totals and words
    val totalsY = maxOf(y + 8f, 632f)
    val totalBundles = invoice.lines.sumOf { it.bundles }
    val totalKg = invoice.lines.sumOf { it.weightKg }

    // Compact total-sum row immediately above the totals; values only, no extra labels.
    val summaryRowTop = totalsY - 18f
    paint.style = Paint.Style.STROKE
    paint.color = light
    canvas.drawRect(30f, summaryRowTop, 565f, summaryRowTop + 18f, paint)
    paint.style = Paint.Style.FILL
    txt("Total Sum", 220f, summaryRowTop + 12f, 8.5f, bold)
    txt(formatNumber(totalBundles), 255f, summaryRowTop + 12f, 8.5f, bold)
    txt(formatNumber(totalKg), 363f, summaryRowTop + 12f, 8.5f, bold)
    val roundedTotal = kotlin.math.round(invoice.total)
    val roundOff = roundedTotal - invoice.total
    // Totals are deliberately placed below the summary row, outside its box.
    txt("Total Amount Before Tax", 330f, totalsY + 10f, 8.5f, bold); txt(money(invoice.subtotal), 485f, totalsY + 10f, 8.5f, bold)
    val gstRates = invoice.lines.map { it.gstPercent }.distinct()
    val igstLabel = if (gstRates.size == 1) "Add : IGST ${formatNumber(gstRates.first())}%" else "Add : IGST"
    txt(igstLabel, 385f, totalsY + 27f, 8.5f); txt(money(invoice.gst), 485f, totalsY + 27f, 8.5f)
    if (invoice.discount > 0) { txt("Discount", 385f, totalsY + 44f, 8.5f); txt("-" + money(invoice.discount), 485f, totalsY + 44f, 8.5f) }
    txt("Round Off", 385f, totalsY + 61f, 8.5f); txt(money(roundOff), 485f, totalsY + 61f, 8.5f)
    box(365f, totalsY + 62f, 565f, totalsY + 91f, invoiceGrey)
    txt("GRAND TOTAL", 380f, totalsY + 81f, 10f, bold, dark)
    txt(money(roundedTotal), 485f, totalsY + 81f, 10f, bold, dark)
    txt("Amount in words:", 30f, totalsY + 24f, 9.5f, bold, grey)
    val words = wrap("Rupees ${amountInWords(roundedTotal)} only", 58)
    words.take(2).forEachIndexed { i, line -> txt(line, 30f, totalsY + 40f + i * 13f, 9.5f, bold) }

    // Declaration
    val decY = 735f
    txt("DECLARATION", 30f, decY, 9f, bold, grey)
    val declarations = listOf(
        "1. Our responsibility ceases as soon as the goods leave from our godown.",
        "2. If any dispute arises it shall have jurisdiction at Salem courts.",
        "3. Buyers will have to bear 5 % shortage on the total weight.",
        "4. Suppliers through loads made under the buyers risk.",
        "5. In the event of any damages, delay in transit etc., we will not be held responsible."
    )
    declarations.forEachIndexed { i, d -> txt(d, 30f, decY + 14f + i * 12f, 7.2f) }

    txt("For Capital Coir Company", 420f, 750f, 9.5f, bold)
    hline(808f)
    val thanks = "Thanks For Your Business"
    bold.textSize = 12f
    val thanksWidth = bold.measureText(thanks)
    txt(thanks, (595f - thanksWidth) / 2f, 833f, 12f, bold, grey)

    document.finishPage(page)
    FileOutputStream(file).use { document.writeTo(it) }
    document.close()
    return file
}

private fun amountInWords(amount: Double): String {
    // Compact Indian-English amount wording suitable for invoices.
    val rupees = amount.toLong()
    val paise = ((amount - rupees) * 100).toInt()
    fun under1000(n: Long): String {
        val ones = arrayOf("Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen")
        val tens = arrayOf("","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety")
        return when {
            n < 20 -> ones[n.toInt()]
            n < 100 -> tens[(n / 10).toInt()] + if (n % 10 != 0L) " " + ones[(n % 10).toInt()] else ""
            else -> ones[(n / 100).toInt()] + " Hundred" + if (n % 100 != 0L) " " + under1000(n % 100) else ""
        }
    }
    fun indian(n: Long): String {
        if (n == 0L) return "Zero"
        var v = n
        val parts = mutableListOf<String>()
        val crore = v / 10000000L; v %= 10000000L
        val lakh = v / 100000L; v %= 100000L
        val thousand = v / 1000L; v %= 1000L
        if (crore > 0) parts += under1000(crore) + " Crore"
        if (lakh > 0) parts += under1000(lakh) + " Lakh"
        if (thousand > 0) parts += under1000(thousand) + " Thousand"
        if (v > 0) parts += under1000(v)
        return parts.joinToString(" ")
    }
    return indian(rupees) + if (paise > 0) " and $paise Paise" else ""
}

private fun createAndShareInvoicePdf(context: Context, invoice: InvoiceRecord, customer: Customer?) {
    val file = invoicePdfFile(context, invoice, customer)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share invoice PDF"))
}

private fun createAndPrintInvoicePdf(context: Context, invoice: InvoiceRecord, customer: Customer?) {
    val file = invoicePdfFile(context, invoice, customer)
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    printManager.print("${invoice.number} - A4 Invoice", object : PrintDocumentAdapter() {
        override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?, cancellationSignal: CancellationSignal?, callback: LayoutResultCallback?, extras: android.os.Bundle?) {
            if (cancellationSignal?.isCanceled == true) { callback?.onLayoutCancelled(); return }
            callback?.onLayoutFinished(
                PrintDocumentInfo.Builder(file.name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(),
                oldAttributes != newAttributes
            )
        }
        override fun onWrite(pages: Array<PageRange>?, destination: ParcelFileDescriptor?, cancellationSignal: CancellationSignal?, callback: WriteResultCallback?) {
            try {
                FileOutputStream(destination!!.fileDescriptor).use { out -> file.inputStream().use { input -> input.copyTo(out) } }
                if (cancellationSignal?.isCanceled == true) callback?.onWriteCancelled() else callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) { callback?.onWriteFailed(e.message) }
        }
    }, null)
}

fun formatNumber(value: Double): String {
    return if (value % 1.0 == 0.0) value.toInt().toString() else "%.2f".format(value).trimEnd('0').trimEnd('.')
}

fun nextInvoiceNumber(invoices: List<InvoiceRecord>): String {
    val now = Date()
    val cal = java.util.Calendar.getInstance().apply { time = now }
    val year = cal.get(java.util.Calendar.YEAR)
    val month = cal.get(java.util.Calendar.MONTH) + 1
    val fyStart = if (month >= 4) year else year - 1
    val fyLabel = "$fyStart-${(fyStart + 1).toString().takeLast(2)}"
    val max = invoices.mapNotNull { inv ->
        val n = inv.number.trim()
        when {
            n.matches(Regex("\\d{3}/\\d{4}-\\d{4}")) -> n.substringBefore('/').toIntOrNull()
            n.startsWith("INV-", ignoreCase = true) -> n.removePrefix("INV-").toIntOrNull()
            else -> null
        }
    }.maxOrNull() ?: 0
    return "%03d/%s".format(Locale.US, max + 1, fyLabel)
}

fun isToday(time: Long): Boolean {
    val f = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
    return f.format(Date(time)) == f.format(Date())
}

fun loadInvoices(context: Context): List<InvoiceRecord> {
    return try {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("items", "[]") ?: "[]"
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val lineArr = o.getJSONArray("lines")
                val lines = buildList {
                    for (j in 0 until lineArr.length()) {
                        val l = lineArr.getJSONObject(j)
                        add(
                            InvoiceLine(
                                l.getString("productName"),
                                l.optString("hsnSac"),
                                l.optString("unit", "Kg"),
                                l.getDouble("rate"),
                                l.getDouble("qty"),
                                l.getDouble("gstPercent"),
                                l.optDouble("bundles", 0.0),
                                l.optDouble("weightKg", 0.0)
                            )
                        )
                    }
                }
                add(
                    InvoiceRecord(
                        o.getString("number"),
                        o.getString("customerName"),
                        o.getLong("dateMillis"),
                        lines,
                        o.optDouble("discount", 0.0),
                        o.optString("shippedFrom", ""),
                        o.optString("shippedTo", ""),
                        o.optString("vehicleName", ""),
                        o.optString("vehicleNumber", ""),
                        o.optString("driverName", o.optString("driverNameDl", "")),
                        o.optString("driverDl", "")
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveInvoices(context: Context, invoices: List<InvoiceRecord>) {
    val arr = JSONArray()
    invoices.forEach { invoice ->
        val o = JSONObject()
            .put("number", invoice.number)
            .put("customerName", invoice.customerName)
            .put("dateMillis", invoice.dateMillis)
            .put("discount", invoice.discount)
            .put("shippedFrom", invoice.shippedFrom)
            .put("shippedTo", invoice.shippedTo)
            .put("vehicleName", invoice.vehicleName)
            .put("vehicleNumber", invoice.vehicleNumber)
            .put("driverName", invoice.driverName)
            .put("driverDl", invoice.driverDl)
        val lineArr = JSONArray()
        invoice.lines.forEach { line ->
            lineArr.put(
                JSONObject()
                    .put("productName", line.productName)
                    .put("hsnSac", line.hsnSac)
                    .put("unit", line.unit)
                    .put("rate", line.rate)
                    .put("qty", line.qty)
                    .put("gstPercent", line.gstPercent)
                    .put("bundles", line.bundles)
                    .put("weightKg", line.weightKg)
            )
        }
        o.put("lines", lineArr)
        arr.put(o)
    }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit().putString("items", arr.toString()).apply()
}

@Composable
fun CustomersScreen(
    customers: List<Customer>,
    onAdd: (Customer) -> Unit,
    onDelete: (Customer) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Customers", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = { show = true }) { Text("+ Add") }
        }
        Spacer(Modifier.height(12.dp))
        if (customers.isEmpty()) {
            EmptyState("No customers yet", "Add your first customer.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(customers, key = { it.id }) { customer ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(customer.name, fontWeight = FontWeight.Bold)
                                Text(customer.phone.ifBlank { "No phone" })
                                Text(customer.gstin.ifBlank { "GSTIN not entered" }, style = MaterialTheme.typography.bodySmall)
                                Text(customer.address, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onDelete(customer) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
    if (show) CustomerDialog(onDismiss = { show = false }, onSave = { onAdd(it); show = false })
}

@Composable
fun CustomerDialog(onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Customer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Customer name *") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(gstin, { gstin = it }, label = { Text("GSTIN") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Address") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) onSave(Customer(name = name.trim(), phone = phone.trim(), gstin = gstin.trim(), address = address.trim()))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProductsScreen(
    products: List<Product>,
    onAdd: (Product) -> Unit,
    onDelete: (Product) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Products", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = { show = true }) { Text("+ Add") }
        }
        Spacer(Modifier.height(12.dp))
        if (products.isEmpty()) {
            EmptyState("No products yet", "Add your products with HSN and GST.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products, key = { it.id }) { product ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(product.name, fontWeight = FontWeight.Bold)
                                Text("HSN: ${product.hsnSac} • ${product.unit} • ₹%.2f".format(product.rate))
                                if (product.bundleWeightKg > 0) {
                                    Text("1 bundle = ${formatNumber(product.bundleWeightKg)} Kg", style = MaterialTheme.typography.bodySmall)
                                }
                                Text("GST ${product.gstPercent}%", style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onDelete(product) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
    if (show) ProductDialog(onDismiss = { show = false }, onSave = { onAdd(it); show = false })
}

@Composable
fun ProductDialog(onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember { mutableStateOf("") }
    var hsn by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("Kg") }
    var bundleWeightKg by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var gst by remember { mutableStateOf("5") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Product name *") }, singleLine = true)
                OutlinedTextField(hsn, { hsn = it }, label = { Text("HSN/SAC") }, singleLine = true)
                OutlinedTextField(unit, { unit = it }, label = { Text("Unit") }, singleLine = true)
                OutlinedTextField(
                    bundleWeightKg, { bundleWeightKg = it },
                    label = { Text("Weight per bundle (Kg)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Text(
                    "Examples: 3 Kg, 7 Kg, 10 Kg. Leave blank for products sold only by bundle.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(rate, { rate = it }, label = { Text("Rate") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(gst, { gst = it }, label = { Text("GST %") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
        },
        confirmButton = {
            Button(onClick = {
                val r = rate.toDoubleOrNull() ?: 0.0
                val g = gst.toDoubleOrNull() ?: 0.0
                val bw = bundleWeightKg.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
                if (name.isNotBlank()) onSave(Product(name = name.trim(), hsnSac = hsn.trim(), unit = unit.trim().ifBlank { "Kg" }, bundleWeightKg = bw, rate = r, gstPercent = g))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SettingsScreen(context: Context) {
    val prefs = remember { context.getSharedPreferences("capital_coir_settings", Context.MODE_PRIVATE) }
    var businessName by remember { mutableStateOf(prefs.getString("businessName", "Capital Coir Company") ?: "Capital Coir Company") }
    var address by remember { mutableStateOf(prefs.getString("address", "") ?: "") }
    var gstin by remember { mutableStateOf(prefs.getString("gstin", "") ?: "") }
    var state by remember { mutableStateOf(prefs.getString("state", "Tamil Nadu") ?: "Tamil Nadu") }
    var stateCode by remember { mutableStateOf(prefs.getString("stateCode", "33") ?: "33") }
    var saved by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("These fields will be used on invoices.")
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(businessName, { businessName = it; saved = false }, label = { Text("Business name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(address, { address = it; saved = false }, label = { Text("Business address") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(gstin, { gstin = it; saved = false }, label = { Text("GSTIN") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(state, { state = it; saved = false }, label = { Text("Registered state") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(stateCode, { stateCode = it; saved = false }, label = { Text("State code") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(14.dp))
        Button(onClick = {
            prefs.edit()
                .putString("businessName", businessName.trim())
                .putString("address", address.trim())
                .putString("gstin", gstin.trim())
                .putString("state", state.trim())
                .putString("stateCode", stateCode.trim())
                .apply()
            saved = true
        }, modifier = Modifier.fillMaxWidth()) { Text("Save Settings") }
        if (saved) {
            Spacer(Modifier.height(8.dp))
            Text("✓ Company details saved successfully", color = Teal, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Text("Invoices are stored locally on this phone.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun EmptyState(title: String, message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(message)
        }
    }
}
