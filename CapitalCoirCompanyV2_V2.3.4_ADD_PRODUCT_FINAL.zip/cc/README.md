# Capital Coir Company V2.3.4

## Add Product crash fix
This release removes the invoice editor's LazyColumn structure. The invoice editor now uses a single ordinary vertically-scrollable Column, so adding/removing invoice lines does not mutate a lazy list's item structure during the same click/recomposition.

- Customer picker works
- Product picker works
- Bundle weight 3/7/10kg/custom supported
- Actual weight editable
- Add Product creates an immutable invoice line and a new List
- Multiple invoice lines supported
- Version 2.3.4 / versionCode 5
