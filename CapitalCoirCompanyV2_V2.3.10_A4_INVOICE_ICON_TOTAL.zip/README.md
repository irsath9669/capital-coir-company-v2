# Capital Coir Company V2

Offline-first Android billing application.

## Stage 2 included
- Working **+ New Invoice** button
- Customer selection
- Multiple product line items
- Bundle quantity and manual weight (Kg), rate and HSN/SAC
- GST calculation per product
- Flat discount
- Subtotal, GST and grand total
- Invoice numbering (INV-0001, INV-0002, ...)
- Local invoice storage on the phone
- Today's sales shown on the dashboard
- Existing customers and products remain in the existing Room database

## Build
The repository includes a GitHub Actions workflow. Push the project to GitHub and the workflow will build a debug APK.

The workflow uploads the APK as:
`CapitalCoirCompany-V2.3.6-debug`


## V2.1 invoice screen
The Home screen + New Invoice button opens the invoice entry screen. Add a customer, add one or more products, enter quantity/discount, and save the invoice locally.

## V2.2 fixes
- Customer selection uses a reliable picker dialog.
- Product selection uses a reliable picker dialog.
- Company details now save and reload from local phone storage.

## V2.3 measurement entry
- After selecting a product, invoice entry now accepts manual Bundles and Weight (Kg).
- For products whose unit contains Kg, GST/taxable amount is calculated from Weight (Kg).
- For other units such as Bundle, GST/taxable amount is calculated from Bundles.
- Both bundle count and weight are retained and shown on the invoice line.


## V2.3 product bundle weights
- Products can store a weight per bundle, such as 3 Kg, 7 Kg, or 10 Kg.
- In a new invoice, selecting a product and entering bundles automatically calculates total weight.
- The calculated weight remains editable for actual weighing.
- For Kg-priced products, billing uses the total weight × rate per Kg.
- Example: Coir Fibre 3kg + 200 bundles = 600 Kg; at ₹40/Kg = ₹24,000 before GST/discount.
- Database migration 1→2 preserves existing customers and products.


## V2.3.1 Add Product stability fix
The Add Product action validates bundle/weight/rate/GST values and catches malformed numeric data so invalid input cannot crash the invoice screen.


## V2.3.2 Add Product crash fix
- Uses a Compose snapshot-backed mutable line list for invoice items.
- Add Product no longer replaces the entire list state during the click callback.
- Product selection is retained after adding, so the screen does not transition through a null product state.
- Invoice rows are rendered from the snapshot list without custom lazy-list keys.
- Numeric parsing remains defensive for bundles, weight, rate and GST.

## V2.3.4 Professional A4 invoice refinements
- Manual invoice number entry (for example 029/2026-2027)
- Larger bold company name on the A4 PDF
- Compact line-wise shipment details
- Separate Driver Name and DL Number fields
- Round Off shown separately and rounded Grand Total
- Larger bold Amount in words
- Removed Authorised Signatory text
- Moved "For Capital Coir Company" upward
- Centered and enlarged "Thanks For Your Business" at the bottom


## V2.3.6 invoice history
- Added a Previous Invoices page accessible from the Invoices bottom navigation tab.
- Saved invoices show invoice number, date, customer, item count, rounded total, and View / Print / Share actions.
- View opens a summary with Print / PDF and Share PDF options.
