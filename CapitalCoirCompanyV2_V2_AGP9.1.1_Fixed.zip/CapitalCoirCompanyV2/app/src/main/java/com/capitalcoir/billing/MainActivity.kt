package com.capitalcoir.billing

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.capitalcoir.billing.data.AppDatabase
import com.capitalcoir.billing.data.Customer
import com.capitalcoir.billing.data.Product
import kotlinx.coroutines.launch

private val Teal = androidx.compose.ui.graphics.Color(0xFF0F766E)
private val LightTeal = androidx.compose.ui.graphics.Color(0xFFE6F2F1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Teal,
                    secondary = Teal,
                    surfaceVariant = LightTeal
                )
            ) {
                CapitalCoirApp(AppDatabase.get(this))
            }
        }
    }
}

enum class Screen(val title: String) {
    HOME("Dashboard"),
    CUSTOMERS("Customers"),
    PRODUCTS("Products"),
    SETTINGS("Settings")
}

@Composable
fun CapitalCoirApp(db: AppDatabase) {
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(Screen.HOME) }
    val customers by db.customerDao().observeAll().collectAsState(initial = emptyList())
    val products by db.productDao().observeAll().collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Capital Coir Company", fontWeight = FontWeight.Bold)
                        Text("Billing & GST • V2", style = MaterialTheme.typography.labelMedium)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Teal,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = screen == Screen.HOME,
                    onClick = { screen = Screen.HOME },
                    icon = { Text("⌂") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = screen == Screen.CUSTOMERS,
                    onClick = { screen = Screen.CUSTOMERS },
                    icon = { Text("👥") },
                    label = { Text("Customers") }
                )
                NavigationBarItem(
                    selected = screen == Screen.PRODUCTS,
                    onClick = { screen = Screen.PRODUCTS },
                    icon = { Text("📦") },
                    label = { Text("Products") }
                )
                NavigationBarItem(
                    selected = screen == Screen.SETTINGS,
                    onClick = { screen = Screen.SETTINGS },
                    icon = { Text("⚙") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    customerCount = customers.size,
                    productCount = products.size,
                    onNewInvoice = { /* Stage 2 */ }
                )
                Screen.CUSTOMERS -> CustomersScreen(
                    customers = customers,
                    onAdd = { c -> scope.launch { db.customerDao().insert(c) } },
                    onDelete = { c -> scope.launch { db.customerDao().delete(c) } }
                )
                Screen.PRODUCTS -> ProductsScreen(
                    products = products,
                    onAdd = { p -> scope.launch { db.productDao().insert(p) } },
                    onDelete = { p -> scope.launch { db.productDao().delete(p) } }
                )
                Screen.SETTINGS -> SettingsScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(customerCount: Int, productCount: Int, onNewInvoice: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Daily Desk", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Offline-first billing. Your data stays on this phone.")
        }
        item {
            Button(
                onClick = onNewInvoice,
                modifier = Modifier.fillMaxWidth().height(58.dp)
            ) {
                Text("+ New Invoice", style = MaterialTheme.typography.titleMedium)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("Customers", customerCount.toString(), Modifier.weight(1f))
                StatCard("Products", productCount.toString(), Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Today's Sales", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("₹0.00", style = MaterialTheme.typography.headlineMedium, color = Teal)
                    Text("Invoices will be added in Stage 2.")
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("V2 foundation", fontWeight = FontWeight.Bold)
                    Text("Local database is active. Customers and products survive app restarts.")
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, color = Teal)
        }
    }
}

@Composable
fun CustomersScreen(
    customers: List<Customer>,
    onAdd: (Customer) -> Unit,
    onDelete: (Customer) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Customers", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = { show = true }) { Text("+ Add") }
        }
        Spacer(Modifier.height(12.dp))
        if (customers.isEmpty()) {
            EmptyState("No customers yet", "Add your first customer.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(customers, key = { it.id }) { customer ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(customer.name, fontWeight = FontWeight.Bold)
                                Text(customer.phone.ifBlank { "No phone" })
                                Text(customer.gstin.ifBlank { "GSTIN not entered" }, style = MaterialTheme.typography.bodySmall)
                                Text(customer.address, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onDelete(customer) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
    if (show) CustomerDialog(
        onDismiss = { show = false },
        onSave = { onAdd(it); show = false }
    )
}

@Composable
fun CustomerDialog(onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Customer") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Customer name *") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(gstin, { gstin = it }, label = { Text("GSTIN") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Address") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank()) onSave(Customer(name = name.trim(), phone = phone.trim(), gstin = gstin.trim(), address = address.trim())) }) {
                Text("Save")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ProductsScreen(
    products: List<Product>,
    onAdd: (Product) -> Unit,
    onDelete: (Product) -> Unit
) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Products", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = { show = true }) { Text("+ Add") }
        }
        Spacer(Modifier.height(12.dp))
        if (products.isEmpty()) {
            EmptyState("No products yet", "Add your products with HSN and GST.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(products, key = { it.id }) { product ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(product.name, fontWeight = FontWeight.Bold)
                                Text("HSN: ${product.hsnSac} • ${product.unit} • ₹%.2f".format(product.rate))
                                Text("GST ${product.gstPercent}%", style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { onDelete(product) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
    if (show) ProductDialog(
        onDismiss = { show = false },
        onSave = { onAdd(it); show = false }
    )
}

@Composable
fun ProductDialog(onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember { mutableStateOf("") }
    var hsn by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("Kg") }
    var rate by remember { mutableStateOf("") }
    var gst by remember { mutableStateOf("5") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Product name *") }, singleLine = true)
                OutlinedTextField(hsn, { hsn = it }, label = { Text("HSN/SAC") }, singleLine = true)
                OutlinedTextField(unit, { unit = it }, label = { Text("Unit") }, singleLine = true)
                OutlinedTextField(rate, { rate = it }, label = { Text("Rate") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(gst, { gst = it }, label = { Text("GST %") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
        },
        confirmButton = {
            Button(onClick = {
                val r = rate.toDoubleOrNull() ?: 0.0
                val g = gst.toDoubleOrNull() ?: 0.0
                if (name.isNotBlank()) onSave(Product(name = name.trim(), hsnSac = hsn.trim(), unit = unit.trim().ifBlank { "Kg" }, rate = r, gstPercent = g))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SettingsScreen() {
    var businessName by remember { mutableStateOf("Capital Coir Company") }
    var address by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var state by remember { mutableStateOf("Tamil Nadu") }
    var stateCode by remember { mutableStateOf("33") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("These fields will be used on invoices in Stage 2.")
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(businessName, { businessName = it }, label = { Text("Business name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(address, { address = it }, label = { Text("Business address") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(gstin, { gstin = it }, label = { Text("GSTIN") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(state, { state = it }, label = { Text("Registered state") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(stateCode, { stateCode = it }, label = { Text("State code") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        Button(onClick = { /* persistence added in next stage */ }, modifier = Modifier.fillMaxWidth()) {
            Text("Save Settings")
        }
        Spacer(Modifier.height(10.dp))
        Text("Backup & Restore will be added with invoices.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun EmptyState(title: String, message: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(message)
        }
    }
}
