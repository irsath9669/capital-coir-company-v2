# Capital Coir Company V2

Offline-first Android billing application.

## Stage 1 included
- Native Android app using Kotlin + Jetpack Compose
- Local Room 3 SQLite database
- Customers: add/list/delete
- Products: add/list/delete
- Basic dashboard
- Settings foundation
- GitHub Actions debug APK build

## Planned next stages
1. GST invoice data model and invoice creation
2. Invoice history + invoice detail
3. A4 PDF generation
4. Android native printing
5. Share/WhatsApp
6. Reports
7. Backup/restore
8. Release APK signing

## Build
The repository includes a GitHub Actions workflow. Run it manually from:
Actions → Build Capital Coir V2 APK

The workflow uploads the debug APK as an artifact.
