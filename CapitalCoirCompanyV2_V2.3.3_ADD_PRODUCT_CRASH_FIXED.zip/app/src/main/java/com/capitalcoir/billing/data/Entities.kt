package com.capitalcoir.billing.data

import androidx.room3.Entity
import androidx.room3.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val gstin: String = "",
    val address: String = "",
    val state: String = "Tamil Nadu",
    val stateCode: String = "33"
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val hsnSac: String = "",
    val unit: String = "Kg",
    val bundleWeightKg: Double = 0.0,
    val rate: Double = 0.0,
    val gstPercent: Double = 5.0
)
