package com.capitalcoir.billing.data

import android.content.Context
import androidx.room3.Database
import androidx.room3.Room
import androidx.room3.RoomDatabase
import androidx.room3.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.async.executeSQL
import androidx.sqlite.driver.AndroidSQLiteDriver

@Database(
    entities = [Customer::class, Product::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun productDao(): ProductDao

    companion object {
        private val MIGRATION_1_2 = Migration(1, 2) { connection: SQLiteConnection ->
            connection.executeSQL("ALTER TABLE products ADD COLUMN bundleWeightKg REAL NOT NULL DEFAULT 0.0")
        }

        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder<AppDatabase>(
                    context.applicationContext,
                    "capital_coir_v2.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .setDriver(AndroidSQLiteDriver())
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
