# Capital Coir Company V2

Offline-first Android billing application.

## Stage 2 included
- Working **+ New Invoice** button
- Customer selection
- Multiple product line items
- Quantity, rate and HSN/SAC
- GST calculation per product
- Flat discount
- Subtotal, GST and grand total
- Invoice numbering (INV-0001, INV-0002, ...)
- Local invoice storage on the phone
- Today's sales shown on the dashboard
- Existing customers and products remain in the existing Room database

## Build
The repository includes a GitHub Actions workflow. Push the project to GitHub and the workflow will build a debug APK.

The workflow uploads the APK as:
`CapitalCoirCompany-V2-debug`
